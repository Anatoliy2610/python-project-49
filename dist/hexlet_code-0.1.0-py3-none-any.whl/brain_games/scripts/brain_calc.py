#!/usr/bin/env python3

from brain_games.games.calc import calc

def hello():
    print ('Welcome to the Brain Games!')
    calc()

def main():
    hello()

if __name__=='__main__':
    main()
