#!/usr/bin/env python3


from brain_games.games.yes_or_no import yes_or_no


def hello():
    print ('Welcome to the Brain Games!')
    yes_or_no()


def main():
    hello()


if __name__ == '__main__':
    main()

