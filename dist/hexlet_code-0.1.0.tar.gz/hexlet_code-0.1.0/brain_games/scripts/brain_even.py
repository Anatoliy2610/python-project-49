#!/usr/bin/env python3


from brain_games.yes_or_no import yes_or_no
from brain_games.yes_or_no import welcome_user

def main():
    yes_or_no()

if __name__ == '__main__':
    main()

