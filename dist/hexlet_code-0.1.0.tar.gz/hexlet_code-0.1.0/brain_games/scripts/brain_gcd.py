from brain_games.games.gcd import game_gcd

def hello():
    print('Welome to the Brain Games!')
    game_gcd()


def main():
    hello()


if __name__ == '__main__':
    main()
